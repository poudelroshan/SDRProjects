extern unsigned char Taltab[],Tal1tab[];
